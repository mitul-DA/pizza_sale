-- 1 Retrieve the total number of orders placed.
SELECT COUNT(order_id) as total FROM orders;

-- 2 Calculate the total revenue generated from pizza sales
SELECT 
    ROUND(SUM(orders_details.quantity * pizzas.price),
            2) AS total_sales
FROM
    orders_details
        JOIN
    pizzas ON orders_details.pizza_id = pizzas.pizza_id;


-- Identify the highest-priced pizza. 

SELECT 
    pizza_types.name, pizzas.price
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
ORDER BY pizzas.price DESC
LIMIT 1;

-- 3 Identify the most common pizza size ordered.
SELECT quantity, COUNT(orders_details.quantity)
FROM orders_details
GROUP BY quantity;

SELECT 
pizzas.size,COUNT(orders_details.quantity) AS total_order
FROM pizzas JOIN orders_details
ON pizzas.pizza_id = orders_details.pizza_id GROUP BY pizzas.size ORDER  BY total_order DESC;


-- 4 List the top 5 most ordered pizza types along with their quantities.
SELECT 
    pizza_types.name, SUM(orders_details.quantity) AS quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    orders_details ON orders_details.pizza_id = pizzas.pizza_id
GROUP BY pizza_types.name
ORDER BY quantity DESC
LIMIT 5;


-- 5 Join the necessary tables to find the total quantity of each pizza category ordered.
SELECT 
    pizza_types.category,
    SUM(orders_details.quantity) AS quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    orders_details ON orders_details.pizza_id = pizzas.pizza_id
GROUP BY pizza_types.category
ORDER BY quantity DESC;


-- 6 Determine the distribution of orders by hour of the day.
SELECT 
    HOUR(order_time) AS hour, COUNT(order_id) AS count
FROM
    orders
GROUP BY HOUR(order_time)
ORDER BY hour;


-- 7 Join relevant tables to find the category-wise distribution of pizzas.
SELECT category,COUNT(name) FROM pizza_types GROUP BY category;


-- 8 Group the orders by date and calculate the average number of pizzas ordered per day.

SELECT 
    ROUND(AVG(quantity), 0)
FROM
    (SELECT 
        orders.order_date, SUM(orders_details.quantity) AS quantity
    FROM
        orders
    JOIN orders_details ON orders.order_id = orders_details.order_id
    GROUP BY orders.order_date) AS order_qantity; 


-- 9 Determine the top 3 most ordered pizza types based on revenue.
SELECT 
    pizza_types.name,
    SUM(pizzas.price * orders_details.quantity) AS revenue
FROM
    pizzas
        JOIN
    orders_details ON pizzas.pizza_id = orders_details.pizza_id
        JOIN
    pizza_types ON pizza_types.pizza_type_id = pizzas.pizza_type_id
GROUP BY pizza_types.name
ORDER BY revenue DESC
LIMIT 3;


-- ADVANCE
-- 10 Calculate the percentage contribution of each pizza type to total revenue.
SELECT 
    pizza_types.category,
    ROUND(SUM(pizzas.price * orders_details.quantity) / (SELECT 
    ROUND(SUM(pizzas.price * orders_details.quantity),2) AS total_sales
    FROM pizzas JOIN orders_details
    ON pizzas.pizza_id = orders_details.pizza_id) * 100,0) AS revenue
FROM
    pizzas
        JOIN
    orders_details ON pizzas.pizza_id = orders_details.pizza_id
        JOIN
    pizza_types ON pizza_types.pizza_type_id = pizzas.pizza_type_id
GROUP BY pizza_types.category
ORDER BY revenue DESC
LIMIT 3;


-- 11  Analyze the cumulative revenue generated over time

SELECT order_date,
ROUND(SUM(revenue) over(order by order_date),0) AS cum_revenue
FROM 
(SELECT orders.order_date,
SUM( orders_details.quantity * pizzas.price) AS revenue
FROM orders_details JOIN pizzas
ON orders_details.pizza_id = pizzas.pizza_id
JOIN orders
ON orders.order_id = orders_details.order_id
GROUP BY orders.order_date) AS sales;

-- 12 Determine the top 3 most ordered pizza types based on revenue for each pizza category. 

SELECT name,revenue FROM 
(SELECT category,name,revenue,
RANK() OVER(PARTITION BY category order by revenue desc) AS rn 
FROM 
(SELECT pizza_types.category,pizza_types.name,
SUM((orders_details.quantity) * pizzas.price) AS revenue
FROM pizza_types JOIN pizzas
ON pizza_types.pizza_type_id = pizzas.pizza_type_id
JOIN orders_details 
ON orders_details.pizza_id = pizzas.pizza_id
GROUP BY pizza_types.category,pizza_types.name) AS a) AS b
WHERE rn <=3;

